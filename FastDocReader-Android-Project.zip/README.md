# 초고속 문서 리더 (HWP/HWPX/PDF)

Android 8.0+ 지원, FastScroller, 초고속 검색이 탑재된 리더 프로젝트입니다.